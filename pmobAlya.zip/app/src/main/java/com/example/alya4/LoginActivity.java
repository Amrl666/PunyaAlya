package com.example.alya4;

import android.app.Activity;

public class LoginActivity extends Activity {
}
